package com.framgia.volleyimagecache.utils;

/**
 * @author Hoalq
 * @date Dec 26, 2014
 */
public class Const {
	public static final String URL_JSON_OBJECT_REQUREST = "http://api.androidhive.info/volley/person_object.json";
	public static final String URL_JSON_ARRAY_REQUEST = "http://api.androidhive.info/volley/person_array.json";
	public static final String URL_STRING_REQUEST = "http://api.androidhive.info/volley/string_response.html";
	public static final String URL_IMAGE_REQUEST = "http://api.androidhive.info/volley/volley-image.jpg";
}
