package in.co.madhur.chatbubblesdemo.model;

/**
 * Created by madhur on 17/01/15.
 */
public enum Status {
    SENT, DELIVERED
}
