package labouardy.com.dailyquotes.model;

/**
 * Created by mlabouardy on 23/03/15.
 */
public class Country {
    private String country;
}
