[//]: # (NOTE: Please put every sentence in its own line, Transifex puts every line in its own translation field!)

## Kako aktivirati OpenKeychain v aplikaciji K-9 Mail?
Za uporabo OpenKeychain v aplikaciji K-9 Mail sledite naslednjim korakom:
  1. Odprite aplikacijo K-9 Mail in dlje časa zadržite prst na računu s katerim želite uporabljati OpenKeychain.
  2. Izberite "Nastavitve računa", se pomaknite na dno in kliknite "Šifriranje".
  3. Kliknite na "Ponudnik OpenPGP" in na seznamu izberite OpenKeychain.

## Našel sem 'hrošča' v aplikaciji OpenKeychain!
Za prijavo hrošča uporabite [sledilnik težav za OpenKeychain](https://github.com/openpgp-keychain/openpgp-keychain/issues).

## Prispevajte
Če želite pomagati pri razvoju aplikacije OpenKeychain in prispevati lastno kodo [prosimo sledite navodilom na Github-u](https://github.com/openpgp-keychain/openpgp-keychain#contribute-code).

## Prevodi
Pomagajte nam pri prevajanju aplikacije OpenKeychain! Svoje prevode lahko prispevate tukaj: [OpenKeychain on Transifex](https://www.transifex.com/projects/p/open-keychain/).